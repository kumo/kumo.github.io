#!/boot/home/config/bin/perl
#
# the All Hallows' Eve script v1.0
#
# kumo
#
# this is based on my xmas.pl script and is part of a little test to 
# generate animated icons (albeit very simple in this case)
# it works by copying the icon attribute from one file to this one.
# still no micro$oft... shame, eh?
# 17th October 2001

# where is the file we should change?
$file="script.pl";
@icons=("pumpkin","pumpkin2", "pumpkin3"); # the icons to use
$index=0; # the current icon
$direction=1; # the index goes 0,1,2,1,0,1,2 etc

print "Hello and welcome!";

while (1==1) {
  # use the cool BeOS "icon-as-an-attribute" to change icon
  `copyattr -n "BEOS:L:STD_ICON" "$icons[$index]" "$file"`;
  
  sleep (rand(5)+1); # sleep for a random amount of time

  # get the next icon
  $index += $direction;
  
  # bounds checking
  $direction = -1 if ($index == 2);
  $direction = 1 if ($index == 0);
}