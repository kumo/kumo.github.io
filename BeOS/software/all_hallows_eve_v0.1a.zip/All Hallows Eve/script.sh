#!/bin/sh
#
# the All Hallows' Eve script v1.0
#
# kumo
#
# this is based on my xmas.pl script and is part of a little test to 
# generate animated icons (albeit very simple in this case)
# it works by copying the icon attribute from one file to this one.
# still no micro$oft... shame, eh?
# 17th October 2001

# where is the file we should change?
file=script.sh
icons=("pumpkin" "pumpkin2" "pumpkin3"); # the icons to use
index=0; # the current icon
direction=1; # the index goes 0,1,2,1,0,1,2 etc

while [ 1 -eq 1 ]
do
  # use the cool BeOS "icon-as-an-attribute" to change icon
  `copyattr -n "BEOS:L:STD_ICON" ${icons[$index]} "$file"`;
  
  # just sleep for 3 seconds ...
  #sleep 3
 
  # otherwise sleep for a random amount (from 1 to 5 seconds)
  # (this takes up more cpu though)
  d=`expr \( $RANDOM % 5 \) + 1`
  sleep $d

  # messy, but if you use "index=`expr $index + $direction`" then the cpu goes too high!
  if [ $index -eq 0 ]
  then
    index=1
    direction=1
  elif [ $index -eq 1 ]
  then
    if [ $direction -eq -1 ]
    then
      index=0
    elif [ $direction -eq 1 ]
    then
      index=2
    fi
  elif [ $index -eq 2 ]
  then
    index=1
    direction=-1
  fi
  
  # bounds checking
#  if [ $index -eq 2 ]
#  then
#    direction=-1
#  elif [ $index -eq 0 ]
#  then
#    direction=1
#  fi
done