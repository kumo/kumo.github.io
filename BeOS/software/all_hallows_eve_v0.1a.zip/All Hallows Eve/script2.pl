#!/boot/home/config/bin/perl
#
# the All Hallows' Eve script v1.0
#
# kumo
#
# this is based on my xmas.pl script and is part of a little test to 
# generate animated icons (albeit very simple in this case)
# it works by copying the icon attribute from a file to this one.
# still no micro$oft... shame, eh?
# 17th October 2001

# where is the file we should change?
$file="script2.pl";

# these are the list of icons to use
@icons=("ghost", "ghost2");
# @icons=("frank", "frank2");
# @icons=("lantern", "lantern2");
 
# the current icon
$index=0;

while (1==1) {
  # use the cool BeOS "icon-as-an-attribute" to change icon
  `copyattr -n "BEOS:L:STD_ICON" "$icons[$index]" "$file"`;

  sleep (rand(5)+1); # sleep for a random amount of time

  # show the other icon next time
  $index = !$index;
}
