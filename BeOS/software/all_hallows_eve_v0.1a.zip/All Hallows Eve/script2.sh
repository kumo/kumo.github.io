#!/bin/sh
#
# it was perl and now it is shell

# where is the file we should change?
file=test.sh

# these are the list of icons to use
#icons=("ghost" "ghost2")
icons=("frank" "frank2")
#icons=("lantern" "lantern2")

# the current icon
index=0

# set up some random values
#for i in 0 1 2 3 4 5 6 7 8 9
#do
#  random[$i] = $i #`expr \( $RANDOM % 5 \) + 1`
#done

# loop forever and ever and ever (ad nauseum)
while [ 1 -eq 1 ]
do
  # use the cool BeOS "icon-as-an-attribute" to change icon
  `copyattr -n "BEOS:L:STD_ICON" ${icons[$index]} "$file"`;

  # just sleep for 3 seconds ...
  #sleep 3
 
  # otherwise sleep for a random amount
  # (this takes up more cpu though)
  d=`expr \( $RANDOM % 5 \) + 1`
  echo $d
  sleep $d
  
  # show the other icon next time
  if [ $index -eq 1 ]
  then
    index=0
  else
    index=1
  fi
done
exit 0