attr_tools © Robert Clarke 2003 (kumo@kumo.it)

Introduction
People.iro allows you to customise the colours of your person filetypes.

Installation
Simply expand the zip file into a directory.

History
v0.2: (20031008)
	added rename_attr
	fixed some warning messages
	list_attr changed the string "Native" to "Origin"
 
v0.1: initial release (20031003)
	added list_attr
	added cat_attr

License and Legal Stuff
The attr_tools package (all files in the archive) is (c) Robert Clarke. All rights reserved. It is freely usable and freely distributable for non-commercial purposes as long as the original archive remains unchanged. In no event shall I be held liable for any damages arising from the use of this software.

Contact
If you have any questions, comments, requests or bug reports, feel free to mail me at
<kumo@kumo.it>.
