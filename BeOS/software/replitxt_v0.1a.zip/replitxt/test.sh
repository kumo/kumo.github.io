#!/bin/sh
#
# the replitxt test script v1.0
#
# kumo
#
# just a very simple script that does nothing other than change the text of a replicant. look out for
# more useful scripts soon!
# 30th November 2001

# what is the ID of the replicant to change?
id=-1;

if [ $id -eq -1 ]
then
  echo "You must edit this script and change \"id=-1\" to match the replicant id"
  echo "(i.e. run replitxt --list)";
  exit 0;
fi

text=("round and round the garden" "like a teddy bear" "one step" "two step" "tickle you under there"); # the text to use
index=0; # the current icon
direction=1; # the index goes 0,1,2,1,0,1,2 etc

while [ 1 -eq 1 ]
do
  # send the text to the replicant
  `replitxt --text $id "${text[$index]}"`;
  
  # otherwise sleep for a random amount (from 1 to 5 seconds)
  # (this takes up more cpu though)
  d=`expr \( $RANDOM % 5 \) + 1`;
  sleep $d;

  index=`expr $index + $direction`;
  if [ $index -eq 0 ]
  then
    direction=1
  elif [ $index -eq 4 ]
  then
    direction=-1
  fi
done